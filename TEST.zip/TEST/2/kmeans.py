# main_kmeans.py
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

def preprocess(df):
    ids = df['id']
    X = df.drop(columns=['id'])
    # 1. 缺失值填補
    X = X.fillna(X.mean())
    # 2. 長尾壓縮
    X = np.log1p(X)
    # 3. 標準化
    X = StandardScaler().fit_transform(X)
    return ids, X

def run_kmeans(X, k=15):
    model = KMeans(n_clusters=k, random_state=42)
    labels = model.fit_predict(X)
    return labels

def main():
    df = pd.read_csv('public_data.csv')
    ids, X = preprocess(df)
    labels = run_kmeans(X, k=15)
    out = pd.DataFrame({'id': ids, 'label': labels})
    out.to_csv('b12202025_public.csv', index=False)

if __name__ == '__main__':
    main()
