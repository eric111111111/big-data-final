# main_hierarchical.py
import pandas as pd
import numpy as np
from sklearn.cluster import AgglomerativeClustering
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import kneighbors_graph

def preprocess(df):
    ids = df['id']
    X = df.drop(columns=['id'])
    # 填補缺失值
    X = X.fillna(X.mean())
    # 長尾壓縮
    X = np.log1p(X)
    # 標準化
    X = StandardScaler().fit_transform(X)
    return ids, X

def run_hierarchical(X, n_clusters=15, n_neighbors=10, linkage='ward'):
    # 使用 kNN 建立稀疏連接圖，降低記憶體使用
    connectivity = kneighbors_graph(X, n_neighbors=n_neighbors, include_self=False)
    model = AgglomerativeClustering(
        n_clusters=n_clusters,
        linkage=linkage,
        connectivity=connectivity
    )
    labels = model.fit_predict(X)
    return labels

def main():
    df = pd.read_csv('public_data.csv')
    ids, X = preprocess(df)
    labels = run_hierarchical(X, n_clusters=15, n_neighbors=10, linkage='ward')
    out = pd.DataFrame({'id': ids, 'label': labels})
    out.to_csv('b12202025_public.csv', index=False)

if __name__ == '__main__':
    main()

