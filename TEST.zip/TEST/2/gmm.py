# main_gmm.py
import pandas as pd
import numpy as np
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler

def preprocess(df):
    ids = df['id']
    X = df.drop(columns=['id'])
    X = X.fillna(X.mean())
    X = np.log1p(X)
    X = StandardScaler().fit_transform(X)
    return ids, X

def run_gmm(X, n_components=15):
    model = GaussianMixture(n_components=n_components, covariance_type='full', random_state=42)
    labels = model.fit_predict(X)
    return labels

def main():
    df = pd.read_csv('public_data.csv')
    ids, X = preprocess(df)
    labels = run_gmm(X, n_components=15)
    out = pd.DataFrame({'id': ids, 'label': labels})
    out.to_csv('b12202025_public.csv', index=False)

if __name__ == '__main__':
    main()
