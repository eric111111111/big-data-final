# main_hdbscan.py
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
import hdbscan

def preprocess(df):
    ids = df['id']
    X = df.drop(columns=['id']).fillna(df.mean()).values
    X_scaled = StandardScaler().fit_transform(np.log1p(X))
    return ids, X_scaled

def main():
    df = pd.read_csv('public_data.csv')
    ids, X = preprocess(df)
    clusterer = hdbscan.HDBSCAN(min_cluster_size=50, prediction_data=True)
    labels = clusterer.fit_predict(X)
    pd.DataFrame({'id': ids, 'label': labels})       .to_csv('b12202025_public.csv', index=False)

if __name__ == '__main__':
    main()
