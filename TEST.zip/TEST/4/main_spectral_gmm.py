# main_spectral_gmm_fixed.py
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import SpectralClustering
from sklearn.mixture import GaussianMixture

def preprocess(df):
    ids = df['id']
    X = df.drop(columns=['id']).fillna(df.mean()).values
    X_scaled = StandardScaler().fit_transform(np.log1p(X))
    return ids, X_scaled

def main():
    df = pd.read_csv('public_data.csv')
    ids, X = preprocess(df)
    
    # 使用稀疏的 nearest_neighbors affinity，降低記憶體使用
    sp = SpectralClustering(
        n_clusters=15,
        affinity='nearest_neighbors',
        n_neighbors=10,
        assign_labels='kmeans',
        random_state=42
    )
    sp_labels = sp.fit_predict(X)
    
    # 將譜聚類結果 one-hot 編碼，再以 GMM 重分群
    embedded = np.zeros((len(X), 15), dtype=int)
    for i in range(15):
        embedded[:, i] = (sp_labels == i).astype(int)
    
    gmm = GaussianMixture(n_components=15, covariance_type='full', random_state=42)
    labels = gmm.fit_predict(embedded)
    
    pd.DataFrame({'id': ids, 'label': labels}) \
      .to_csv('b12202025_public.csv', index=False)

if __name__ == '__main__':
    main()
