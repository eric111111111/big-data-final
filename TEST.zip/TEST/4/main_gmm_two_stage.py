# main_gmm_two_stage_fixed.py
import pandas as pd
import numpy as np
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler

def preprocess(df):
    ids = df['id']
    X = df.drop(columns=['id']).fillna(df.mean()).values
    X_scaled = StandardScaler().fit_transform(np.log1p(X))
    return ids, X_scaled

def main():
    df = pd.read_csv('public_data.csv')
    ids, X = preprocess(df)
    
    # 第一階段：粗分為 3 群
    gmm1 = GaussianMixture(n_components=3, covariance_type='full', random_state=42)
    labels1 = gmm1.fit_predict(X)
    
    # 準備儲存最終標籤
    final_labels = np.empty_like(labels1)
    current_label = 0
    
    # 第二階段：對每個大群再細分 5 群
    for g in np.unique(labels1):
        # 取得該群的索引
        group_idx = np.where(labels1 == g)[0]
        X_sub = X[group_idx]
        
        # 若子群樣本數不足，直接標一群
        if X_sub.shape[0] < 5:
            final_labels[group_idx] = current_label
            current_label += 1
            continue
        
        # 在子群上做細分
        gmm2 = GaussianMixture(n_components=5, covariance_type='full', random_state=42)
        sub_labels = gmm2.fit_predict(X_sub)
        
        # 映射回原始索引
        for sl in np.unique(sub_labels):
            sub_idx = group_idx[sub_labels == sl]
            final_labels[sub_idx] = current_label
            current_label += 1
    
    # 輸出結果
    pd.DataFrame({'id': ids, 'label': final_labels}) \
      .to_csv('b12202025_public.csv', index=False)

if __name__ == '__main__':
    main()
