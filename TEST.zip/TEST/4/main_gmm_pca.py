# main_gmm_pca_var95.py
import pandas as pd
import numpy as np
from sklearn.mixture import GaussianMixture
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

def preprocess(df):
    ids = df['id']
    X = df.drop(columns=['id']).fillna(df.mean()).values
    # log1p 壓縮長尾，然後標準化
    X_scaled = StandardScaler().fit_transform(np.log1p(X))
    # PCA 自動選擇解釋度 ≥ 95% 的維度
    pca = PCA(n_components=0.95, random_state=42)
    X_pca = pca.fit_transform(X_scaled)
    print(f"PCA 選擇維度數：{pca.n_components_}")
    return ids, X_pca

def run_gmm(X):
    model = GaussianMixture(
        n_components=15,
        covariance_type='full',
        random_state=42
    )
    return model.fit_predict(X)

def main():
    df = pd.read_csv('public_data.csv')
    ids, X = preprocess(df)
    labels = run_gmm(X)
    pd.DataFrame({'id': ids, 'label': labels}) \
      .to_csv('b12202025_public.csv', index=False)

if __name__ == '__main__':
    main()
