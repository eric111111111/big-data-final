# main_bayesiangmm.py
import pandas as pd
import numpy as np
from sklearn.mixture import BayesianGaussianMixture
from sklearn.preprocessing import StandardScaler

def preprocess(df):
    ids = df['id']
    X = df.drop(columns=['id']).fillna(df.mean()).values
    X_scaled = StandardScaler().fit_transform(np.log1p(X))
    return ids, X_scaled

def run_bayesian_gmm(X, max_components=30):
    model = BayesianGaussianMixture(n_components=max_components,
                                    covariance_type='full',
                                    weight_concentration_prior_type='dirichlet_process',
                                    random_state=42)
    labels = model.fit_predict(X)
    return labels

def main():
    df = pd.read_csv('public_data.csv')
    ids, X = preprocess(df)
    labels = run_bayesian_gmm(X)
    pd.DataFrame({'id': ids, 'label': labels})       .to_csv('b12202025_public.csv', index=False)

if __name__ == '__main__':
    main()
