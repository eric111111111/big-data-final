# loop.py
import pandas as pd
import numpy as np
import itertools
import hdbscan
from sklearn.preprocessing import StandardScaler

# ---------------- 載入 grader ----------------
from grader import score   # 評分函式 (同 eval.py 使用)

# ---------------- 資料前處理 ----------------
df  = pd.read_csv('public_data.csv')
ids = df['id'].values
X   = np.log1p(df.drop(columns=['id']).fillna(df.mean()).values)
X   = StandardScaler().fit_transform(X)

# ---------------- 參數搜尋網格 ----------------
grid_mcs = [80, 90, 100, 110, 120]      # 可自行增刪
grid_ms  = [3, 10, 15, 20, 30]

best_score, best_mcs, best_ms = -1, None, None

print("mcs  ms   #clusters   Score")
print("-"*30)

for mcs, ms in itertools.product(grid_mcs, grid_ms):
    labels = hdbscan.HDBSCAN(
        min_cluster_size=mcs,
        min_samples=ms,
        prediction_data=False
    ).fit_predict(X)

    # 計算 FMI；grader.score 接收 list[int]
    score_val = score(labels.tolist())
    n_clusters = len(np.unique(labels[labels >= 0]))
    print(f"{mcs:<4} {ms:<4} {n_clusters:<10} {score_val:.4f}")

    # 若刷新最佳，儲存並覆寫
    if score_val > best_score:
        best_score, best_mcs, best_ms = score_val, mcs, ms
        pd.DataFrame({'id': ids, 'label': labels}) \
          .to_csv('b12202025_public_best.csv', index=False)

print("\nBest setting → "
      f"mcs={best_mcs}, ms={best_ms}, FMI={best_score:.4f}")
print("最佳結果已輸出到 b12202025_public_best.csv")

