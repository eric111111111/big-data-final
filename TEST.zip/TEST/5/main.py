# main.py
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
import hdbscan

def main():
    # 1. 讀取資料
    df = pd.read_csv('private_data.csv')
    ids = df['id']
    X = df.drop(columns=['id']).fillna(df.mean()).values

    # 2. 特徵前處理：log1p + z‑score
    X = np.log1p(X)
    X = StandardScaler().fit_transform(X)

    # 3. HDBSCAN 分群（min_cluster_size 與 min_samples 均設為 50）
    clusterer = hdbscan.HDBSCAN(
        min_cluster_size=80,
        min_samples=20,
        prediction_data=False
    )
    labels = clusterer.fit_predict(X)

    # 4. 輸出結果
    out = pd.DataFrame({'id': ids, 'label': labels})
    out.to_csv('private_submission.csv', index=False)

if __name__ == '__main__':
    main()
