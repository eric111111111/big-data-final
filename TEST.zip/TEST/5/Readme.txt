TEST.py is for parameter searching
Main.py is the final code